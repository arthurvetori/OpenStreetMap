data.py
- its the main script and contains functions for auditing and processing the data

clean.py
- auxiliar module with cleaning functions

dbadapter.py
- auxiliar module with database functions, also includes ip, port and database configuration for database.
- change ip, port and database to desired ones.

map.xml.json
- contains the map json for all_data collection in script

map_detailed.xml.json
- contains only data with inner tags 'k'

project document.pdf
- document file writing all analysis done in this project



####### REFERENCES USED #########

https://classroom.udacity.com/
https://stackoverflow.com/
https://docs.mongodb.com/
https://wiki.openstreetmap.org/
